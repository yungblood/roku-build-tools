curl the next few years - perhaps
=================================

Roadmap of things Daniel Stenberg wants to work on next. It is intended to
serve as a guideline for others for information, feedback and possible
participation.

HSTS
----

 Merge [the existing PR](https://github.com/curl/curl/pull/5896).

ECH (Encrypted Client Hello - formerly known as ESNI)
-----------------------------------------------------

 See Daniel's post on [Support of Encrypted
 SNI](https://curl.haxx.se/mail/lib-2019-03/0000.html) on the mailing list.

 Initial work exists in https://github.com/curl/curl/pull/4011
